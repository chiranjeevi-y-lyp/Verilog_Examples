vlib work
#compilation
vlog seq_det_1011_moore.v
vlog seq_det_1011_moore_tb.v

#elaboration
vsim -novopt -suppress 12110 tb

#simulation
add wave -position insertpoint sim:/tb/dut/*
run -all
