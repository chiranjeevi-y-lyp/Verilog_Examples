module sequence_det_1010(
 input clk,
 input rst_n,
 input x,
 output reg y);

 parameter  SR   = 2'b00;
 parameter  S1   = 2'b01;
 parameter  S10  = 2'b10;
 parameter  S101 = 2'b11;

 reg[1:0] present_state,next_state;

 always @(posedge clk or negedge rst_n)begin
      if(!rst_n)begin
	    present_state <= SR;
	  end
	  else begin
	    present_state <= next_state;
	  end
 end

 always @(*)begin
  y = 1'b0;
    case(present_state)
	  SR:begin
	    if(x == 1)begin
		  next_state = S1;
		end
		else begin
		  next_state = SR;
		end
	  end
	  S1:begin
	    if(x == 0)begin
		  next_state = S10;
		end
		else begin
		  next_state = S1;
		end
	  end
	  S10:begin
	    if(x == 1)begin
		  next_state = S101;
		end
		else begin
		  next_state = SR;
		end
	  end
	  S101:begin
	    if(x == 0)begin
		  next_state = SR;
		  y = 1;
		end
		else begin
		  next_state = S1;
		end
	  end
	  default:next_state = SR;
	endcase
 end


 endmodule
                        
