vlib work
#compilation
vlog seq_det_1011.v
vlog seq_det_1011_tb.v

#elaboration
vsim -novopt -suppress 12110 tb

#simulation
add wave -position insertpoint sim:/tb/dut/*
run -all
