module tb;

    reg clk;
    reg rst_n;
    reg x;
    wire y;

    // Instantiate DUT
    sequence_det_1011 dut (
        .clk(clk),
        .rst_n(rst_n),
        .x(x),
        .y(y)
    );

    always #5 clk = ~clk;

    initial begin
        // Initialize signals
        clk   = 0;
        rst_n = 0;
        x     = 0;

        // Apply reset
        #12;
        rst_n = 1;

        // Apply test sequence: 1 0 1 1 1 0 1 1
        #10 x = 1;
        #10 x = 0;
        #10 x = 1;
        #10 x = 1;   // First detection here (1011)
        #10 x = 1;
        #10 x = 0;
        #10 x = 1;
        #10 x = 1;   // Second detection here

        #20;
        $finish;
    end

    // Monitor values
    initial begin
        $monitor("Time=%0t | x=%b | y=%b", $time, x, y);
    end

endmodule
