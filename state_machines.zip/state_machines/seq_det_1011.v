module sequence_det_1011(
 input clk,
 input rst_n,
 input x,
 output reg y
);

 parameter  SR   = 2'b00;
 parameter  S1   = 2'b01;
 parameter  S10  = 2'b10;
 parameter  S101 = 2'b11;

 reg [1:0] present_state, next_state;

 always @(posedge clk or negedge rst_n) begin
     if(!rst_n)
         present_state <= SR;
     else
         present_state <= next_state;
 end

 always @(*) begin
     y = 1'b0;

     case(present_state)

         SR: begin
             if(x == 1)
                 next_state = S1;
             else
                 next_state = SR;
         end

         S1: begin
             if(x == 0)
                 next_state = S10;
             else
                 next_state = S1;
         end

         S10: begin
             if(x == 1)
                 next_state = S101;
             else
                 next_state = SR;
         end

         S101: begin
             if(x == 1) begin
                 next_state = SR;   
                 y = 1'b1;          // 1011 detected
             end
             else
                 next_state = S10;
         end

         default: next_state = SR;
     endcase
 end

endmodule
