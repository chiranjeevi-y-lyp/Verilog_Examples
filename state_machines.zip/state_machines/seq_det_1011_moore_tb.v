module tb;

    reg clk;
    reg rst_n;
    reg x;
    wire y;

    sequence_det_1011_moore dut (
        .clk(clk),
        .rst_n(rst_n),
        .x(x),
        .y(y)
    );

    always #5 clk = ~clk;

    initial begin
        // Initialize signals
        clk   = 0;
        rst_n = 0;
        x     = 0;

        // Apply reset
        #12;
        rst_n = 1;

        // Test sequence: 1 0 1 1 1 0 1 1
        #10 x = 1;
        #10 x = 0;
        #10 x = 1;
        #10 x = 1;   // First detection here (Moore output y=1)
        #10 x = 1;
        #10 x = 0;
        #10 x = 1;
        #10 x = 1;   // Second detection

        #20;
        $finish;
    end

    // Monitor signals
    initial begin
        $monitor("Time=%0t | x=%b | y=%b", $time, x, y);
    end

endmodule
