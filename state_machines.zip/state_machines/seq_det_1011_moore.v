module sequence_det_1011_moore(
    input clk,
    input rst_n,
    input x,
    output reg y
);

    parameter SR     = 3'b000;   // No match
    parameter S1     = 3'b001;   // Saw 1
    parameter S10    = 3'b010;   // Saw 10
    parameter S101   = 3'b011;   // Saw 101
    parameter S1011  = 3'b100;   // Saw 1011 (output = 1)

    reg [2:0] state, next_state;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            state <= SR;
        else
            state <= next_state;
    end

    always @(*) begin
        case (state)
            SR: begin
                if (x == 1)
                    next_state = S1;
                else
                    next_state = SR;
            end

            S1: begin
                if (x == 1)
                    next_state = S1;
                else
                    next_state = S10;
            end

            S10: begin
                if (x == 1)
                    next_state = S101;
                else
                    next_state = SR;
            end

            S101: begin
                if (x == 1)
                    next_state = S1011;
                else
                    next_state = S10;
            end

            S1011: begin
                // Non-overlapping reset
                if (x == 1)
                    next_state = S1;
                else
                    next_state = SR;
            end

            default: next_state = SR;
        endcase
    end

    // Output logic (Moore)
    always @(*) begin
        case (state)
            S1011: y = 1'b1;
            default: y = 1'b0;
        endcase
    end

endmodule
