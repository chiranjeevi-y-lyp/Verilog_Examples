module tb;

    reg clk;
    reg rst_n;
    reg x;
    wire y;

    sequence_det_1010 dut (
        .clk(clk),
        .rst_n(rst_n),
        .x(x),
        .y(y)
    );

    always #5 clk = ~clk;

    initial begin
        // Initialize
        clk = 0;
        rst_n = 0;
        x = 0;

        // Apply reset
        #10;
        rst_n = 1;

        // Apply test sequence: 1 0 1 0 1 0
        #10 x = 1;
        #10 x = 0;
        #10 x = 1;
        #10 x = 0;   // Detection here (y = 1)
        #10 x = 1;
        #10 x = 0;   // No detection (non-overlapping)

        #20;
        $finish;
    end

    // Monitor values
    initial begin
        $monitor("Time=%0t | x=%b | y=%b", $time, x, y);
    end

endmodule
