module melay(
input clk,
input rst,
input valid,
input in,
output reg out
);

parameter SR   = 4'b0001;
parameter S1   = 4'b0010;
parameter S10  = 4'b0100;
parameter S101 = 4'b1000;

reg [3:0] present_st, next_st;


// State Register
always @(posedge clk or posedge rst) begin
    if (rst)
        present_st <= SR;
    else if(valid)
        present_st <= next_st;
end



always @(*) begin
    out = 0;

    case(present_st)

    SR: begin
        if(in == 1)
            next_st = S1;
        else
            next_st = SR;
    end

    S1: begin
        if(in == 0)
            next_st = S10;
        else
            next_st = S1;
    end

    S10: begin
        if(in == 1)
            next_st = S101;
        else
            next_st = SR;
    end

    S101: begin
        if(in == 1) begin
            next_st = SR;
            out = 1;   // sequence detected
        end
        else
            next_st = S10;
    end

    default: next_st = SR;

    endcase
end

endmodule
