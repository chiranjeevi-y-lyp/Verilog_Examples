module synch_fifo #(parameter WIDTH = 8,
                    parameter DEPTH = 16,
                    parameter PTR_WIDTH = $clog2(DEPTH))
(
input clk,
input rst_n,
input wr_en,
input rd_en,
input [WIDTH-1:0] wdata,
output reg [WIDTH-1:0] rdata,
output full,
output empty,
output reg wr_error,
output reg rd_error
);

reg [PTR_WIDTH-1:0] wr_ptr;
reg [PTR_WIDTH-1:0] rd_ptr;

reg wr_toggle_f;
reg rd_toggle_f;

reg [WIDTH-1:0] fifo [0:DEPTH-1];

integer i;

always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
    rdata <= 0;
    wr_ptr <= 0;
    rd_ptr <= 0;
    wr_toggle_f <= 0;
    rd_toggle_f <= 0;
    wr_error <= 0;
    rd_error <= 0;

    for(i=0;i<DEPTH;i=i+1)
       fifo[i] <= 0;
  end
  else begin

    wr_error <= 0;
    rd_error <= 0;

    // WRITE
    if(wr_en) begin
      if(full)
        wr_error <= 1;
      else begin
        fifo[wr_ptr] <= wdata;

        if(wr_ptr == DEPTH-1) begin
           wr_ptr <= 0;
           wr_toggle_f <= ~wr_toggle_f;
        end
        else
           wr_ptr <= wr_ptr + 1;
      end
    end

    // READ
    if(rd_en) begin
      if(empty)
        rd_error <= 1;
      else begin
        rdata <= fifo[rd_ptr];

        if(rd_ptr == DEPTH-1) begin
           rd_ptr <= 0;
           rd_toggle_f <= ~rd_toggle_f;
        end
        else
           rd_ptr <= rd_ptr + 1;
      end
    end

  end
end

assign full  = (wr_ptr == rd_ptr) && (wr_toggle_f != rd_toggle_f);
assign empty = (wr_ptr == rd_ptr) && (wr_toggle_f == rd_toggle_f);

endmodule
