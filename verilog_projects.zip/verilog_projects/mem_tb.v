`timescale 1ns/1ps

module tb;

parameter WIDTH = 8;
parameter DEPTH = 16;
parameter ADDR_WIDTH = $clog2(DEPTH);

reg clk;
reg rst;
reg valid;
reg wr_rd;
reg [ADDR_WIDTH-1:0] addr;
reg [WIDTH-1:0] wdata;

wire [WIDTH-1:0] rdata;
wire ready;

// DUT Instantiation
mem #(WIDTH, DEPTH, ADDR_WIDTH) dut (
    .clk(clk),
    .rst(rst),
    .valid(valid),
    .wr_rd(wr_rd),
    .addr(addr),
    .wdata(wdata),
    .rdata(rdata),
    .ready(ready)
);

// Clock generation
always #5 clk = ~clk;

integer i;

initial begin

    clk = 0;
    rst = 0;
    valid = 0;
    wr_rd = 0;
    addr = 0;
    wdata = 0;

    //--------------------------------
    // TESTCASE 1 : RESET VERIFICATION
    //--------------------------------
    #20;
    rst = 1;
    $display("Reset Released");

    //--------------------------------
    // TESTCASE 2 : SINGLE WRITE
    //--------------------------------
    @(posedge clk);
    valid = 1;
    wr_rd = 1;
    addr = 4;
    wdata = 8'hA5;

    @(posedge clk);
    valid = 0;

    //--------------------------------
    // TESTCASE 3 : SINGLE READ
    //--------------------------------
    @(posedge clk);
    valid = 1;
    wr_rd = 0;
    addr = 4;

    @(posedge clk);
    valid = 0;

    //--------------------------------
    // TESTCASE 4 : WRITE THEN READ
    //--------------------------------
    @(posedge clk);
    valid = 1;
    wr_rd = 1;
    addr = 2;
    wdata = 8'h55;

    @(posedge clk);
    wr_rd = 0;
    addr = 2;

    @(posedge clk);
    valid = 0;

    //--------------------------------
    // TESTCASE 5 : VALID = 0 (NO OP)
    //--------------------------------
    @(posedge clk);
    valid = 0;
    addr = 5;
    wdata = 8'hFF;

    //--------------------------------
    // TESTCASE 6 : MULTIPLE WRITE/READ
    //--------------------------------
    for(i=0;i<5;i=i+1) begin
        @(posedge clk);
        valid = 1;
        wr_rd = 1;
        addr = i;
        wdata = i + 10;
    end

    valid = 0;

    for(i=0;i<5;i=i+1) begin
        @(posedge clk);
        valid = 1;
        wr_rd = 0;
        addr = i;
    end

    @(posedge clk);
    valid = 0;

    #50;
    $finish;

end

// Monitor signals
initial begin
$monitor("time=%0t valid=%b wr_rd=%b addr=%d wdata=%h rdata=%h ready=%b",
          $time, valid, wr_rd, addr, wdata, rdata, ready);
end

endmodule
