module mem #(parameter WIDTH = 8,
             parameter DEPTH = 16,
             parameter ADDR_WIDTH = $clog2(DEPTH))
(
input clk,
input rst,
input valid,
input wr_rd,               
input [ADDR_WIDTH-1:0] addr,
input [WIDTH-1:0] wdata,
output reg [WIDTH-1:0] rdata,
output reg ready
);

reg [WIDTH-1:0] mem [DEPTH-1:0];
integer i;

always @(posedge clk) begin

    if(!rst) begin
        ready <= 1'b0;
        rdata <= {WIDTH{1'b0}};
        
        for(i=0; i<DEPTH; i=i+1) begin
            mem[i] <= 0;
        end
    end
    
    else begin
        ready <= 0;

        if(valid) begin
        
            if(wr_rd) begin
                mem[addr] <= wdata;
                ready <= 1;
            end
            
            else begin
                rdata <= mem[addr];
                ready <= 1;
            end
            
        end
    end

end

endmodule
