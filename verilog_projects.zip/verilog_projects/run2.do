vlib work
#compilation
vlog synch_fifo.v
vlog fifo_tb.v

#elaboration
vsim -novopt -suppress 12110 tb

#simulation
add wave -position insertpoint sim:/tb/dut/*
run -all

