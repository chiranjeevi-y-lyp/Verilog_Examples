vlib work
#compilation
vlog pattern_det_1011.v
vlog melay_tb.v

#elaboration
vsim -novopt -suppress 12110 tb

#simulation
add wave -position insertpoint sim:/tb/dut/*
run -all


