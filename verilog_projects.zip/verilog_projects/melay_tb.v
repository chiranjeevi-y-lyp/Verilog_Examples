`timescale 1ns/1ps

module tb;

reg clk;
reg rst;
reg valid;
reg in;
wire out;

melay dut(
    .clk(clk),
    .rst(rst),
    .valid(valid),
    .in(in),
    .out(out)
);

// Clock generation (10ns period)
always #5 clk = ~clk;

initial begin
    // Initialize
    clk = 0;
    rst = 1;
    valid = 0;
    in = 0;

    // Apply reset
    #10;
    rst = 0;
    valid = 1;

    // Input sequence
    // Testing sequence: 1 0 1 1 -> should detect

    #10 in = 1;
    #10 in = 0;
    #10 in = 1;
    #10 in = 1;   // out should become 1

    // Another sequence
    #10 in = 0;
    #10 in = 1;
    #10 in = 0;
    #10 in = 1;
    #10 in = 1;   // detect again

    // Random inputs
    #10 in = 1;
    #10 in = 1;
    #10 in = 0;
    #10 in = 1;
    #10 in = 1;

    #50 $finish;
end

// Monitor signals
initial begin
   $monitor("time=%0t in=%b out=%b state=%b", $time, in, out, dut.present_st);
end

endmodule
