`timescale 1ns/1ps

module tb;

parameter WIDTH = 8;
parameter DEPTH = 16;
parameter PTR_WIDTH = $clog2(DEPTH);

reg clk;
reg rst_n;
reg wr_en;
reg rd_en;
reg [WIDTH-1:0] wdata;

wire [WIDTH-1:0] rdata;
wire full;
wire empty;
wire wr_error;
wire rd_error;


// DUT Instantiation
synch_fifo #(WIDTH,DEPTH,PTR_WIDTH) dut (
    .clk(clk),
    .rst_n(rst_n),
    .wr_en(wr_en),
    .rd_en(rd_en),
    .wdata(wdata),
    .rdata(rdata),
    .full(full),
    .empty(empty),
    .wr_error(wr_error),
    .rd_error(rd_error)
);



// Clock generation
always #5 clk = ~clk;

integer i;

initial begin

    clk = 0;
    rst_n = 0;
    wr_en = 0;
    rd_en = 0;
    wdata = 0;

    // Apply Reset
    #20;
    rst_n = 1;

    //------------------------------------------------
    // WRITE DATA INTO FIFO
    //------------------------------------------------
    $display("Writing into FIFO");

    for(i=0;i<16;i=i+1) begin
        @(posedge clk);
        wr_en = 1;
        rd_en = 0;
        wdata = i;
    end

    @(posedge clk);
    wr_en = 0;

    //------------------------------------------------
    // TRY WRITING WHEN FIFO FULL
    //------------------------------------------------
    @(posedge clk);
    wr_en = 1;
    wdata = 8'hAA;

    @(posedge clk);
    wr_en = 0;

    //------------------------------------------------
    // READ DATA FROM FIFO
    //------------------------------------------------
    $display("Reading from FIFO");

    for(i=0;i<16;i=i+1) begin
        @(posedge clk);
        rd_en = 1;
        wr_en = 0;
    end

    @(posedge clk);
    rd_en = 0;

    //------------------------------------------------
    // TRY READING WHEN FIFO EMPTY
    //------------------------------------------------
    @(posedge clk);
    rd_en = 1;

    @(posedge clk);
    rd_en = 0;

    #50;
    $finish;

end



// Monitor signals
initial begin
$monitor("time=%0t wr_en=%b rd_en=%b wdata=%h rdata=%h full=%b empty=%b wr_error=%b rd_error=%b",
          $time, wr_en, rd_en, wdata, rdata, full, empty, wr_error, rd_error);
end

endmodule
