module pipo_register4 (
    input clk,
    input reset,
    input [3:0] d,
    output reg [3:0] q
);

always @(posedge clk or posedge reset)begin
    if (reset)
        q <= 4'b0000;
    else
        q <= d;
end

endmodule
