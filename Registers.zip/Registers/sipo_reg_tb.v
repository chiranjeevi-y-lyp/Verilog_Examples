module tb;

reg clk;
reg reset;
reg serial_in;
wire [3:0] q;

// Instantiate DUT
sipo_reg dut (
    .clk(clk),
    .reset(reset),
    .serial_in(serial_in),
    .q(q)
);

// Clock generation (10ns period)
always #5 clk = ~clk;

initial begin
    // Initialize signals
    clk = 0;
    reset = 1;      // Apply reset
    serial_in = 0;

    #10 reset = 0;  // Release reset

    // Apply serial data
    serial_in = 1;
    #10 serial_in = 0;
    #10 serial_in = 1;
    #10 serial_in = 1;

    // Apply reset again in middle
    #10 reset = 1;
    #10 reset = 0;

    #20 serial_in = 1;
    #20 $finish;
end

// Monitor output
initial begin
    $monitor("Time=%0t | clk=%b | serial_in=%b | q=%b",
              $time, clk, serial_in, q);
end

endmodule
