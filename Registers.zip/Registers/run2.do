vlib work
#compilation
vlog sipo_reg.v
vlog sipo_reg_tb.v

#elaboration
vsim -novopt -suppress 12110 tb

#simulation
add wave -position insertpoint sim:/tb/dut/*
run -all
