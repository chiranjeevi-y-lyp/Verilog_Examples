module piso_4bit (
    input wire clk,           // Clock
    input wire rst,           // Synchronous reset
    input wire load,          // Load control (1 = load, 0 = shift)
    input wire [3:0] data_in, // Parallel input
    output wire serial_out    // Serial output
);

    reg [3:0] shift_reg;

    always @(posedge clk) begin
        if (rst)
            shift_reg <= 4'b0000;          // Reset register
        else if (load)
            shift_reg <= data_in;          // Load parallel data
        else
            shift_reg <= {1'b0, shift_reg[3:1]}; // Shift right
    end

    assign serial_out = shift_reg[0];      // LSB first output

endmodule
