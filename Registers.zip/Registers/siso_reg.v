module siso_reg (
    input clk,
	input reset,
    input serial_in,
    output reg [3:0] q,
	output serial_out);

always @(posedge clk or posedge reset)begin
    if(reset)begin
	  q <= 4'b0000;
	end
	else begin
      q <= {q[2:0], serial_in};
	end
end

assign serial_out = q[3];

endmodule
