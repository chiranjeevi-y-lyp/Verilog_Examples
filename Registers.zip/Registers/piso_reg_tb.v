module tb;

    reg clk;
    reg rst;
    reg load;
    reg [3:0] data_in;
    wire serial_out;

    // Instantiate the DUT 
    piso_4bit dut (
        .clk(clk),
        .rst(rst),
        .load(load),
        .data_in(data_in),
        .serial_out(serial_out)
    );

    // Clock generation (10ns period)
    always #5 clk = ~clk;

    initial begin
        // Initialize signals
        clk = 0;
        rst = 1;
        load = 0;
        data_in = 4'b0000;

        // Apply reset
        #10;
        rst = 0;

        // Load data
        #10;
        load = 1;
        data_in = 4'b1101;   // Example data

        #10;
        load = 0;            // Start shifting

        // Wait for 4 clock cycles to shift all bits
        #50;

        // Load another value
        load = 1;
        data_in = 4'b1010;

        #10;
        load = 0;

        #50;

        $finish;
    end

    // Monitor values
    initial begin
        $monitor("Time=%0t | load=%b | data_in=%b | serial_out=%b",
                 $time, load, data_in, serial_out);
    end

endmodule
