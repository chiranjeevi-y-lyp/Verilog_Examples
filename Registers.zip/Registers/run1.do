vlib work
#compilation
vlog siso_reg.v
vlog siso_reg_tb.v

#elaboration
vsim -novopt -suppress 12110 tb

#simulation
add wave -position insertpoint sim:/tb/dut/*
run -all
