module tb;
 reg clk;
 reg reset;
 reg[3:0] d;
 wire[3:0] q;

 pipo_register4 dut(.clk(clk), .reset(reset), .d(d), .q(q));

 always #5 clk = ~clk;

 initial begin
  clk = 0;
  reset = 1;
  d = 4'b0000;
  #10;
  reset = 0;
  repeat(5)begin
   d = $random;
   #10;
  end
  $finish();
 end

 initial begin
  $monitor($time," clk=%b reset=%b d=%b q=%b",clk,reset,d,q);
 end
endmodule
