vlib work
#compilation
vlog pipo_reg.v
vlog pipo_reg_tb.v

#elaboration
vsim -novopt -suppress 12110 tb

#simulation
add wave -position insertpoint sim:/tb/dut/*
run -all
